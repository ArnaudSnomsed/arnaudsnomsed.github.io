//////////////////////////////////////////////
//                                          //             
//       LA PROJECTION PERSPECTIVE	    //
//           copyright Logarno              //
//          logarno@planet-d.net            //
//      http://logarno.planet-d.net         //
//                                          //
//////////////////////////////////////////////

#include <sys/nearptr.h>
#include <dos.h>

typedef struct
{
  int x,y,z;
} D3;

typedef struct
{
  int x,y;
} D2;

void put_pixel(unsigned char *bitmap, int x, int y, unsigned char color)
{
bitmap[(y << 8) + (y << 6) + x] = color;
}

void line(unsigned char *bitmap, int x1,int y1, int x2,int y2, unsigned char color)
{
  int x,y,xinc,yinc,diff,i;
  int dx = abs(x2-x1);
  int dy = abs(y2-y1);

  if(x1<x2) xinc = 1;
  else	xinc = -1;

  if(y1<y2) yinc = 1;
  else	yinc = -1;

  x = x1;
  y = y1;

  if(dx>dy)
    {
      diff = dx/2;     
      for(i=0;i<dx;i++)
	{
	  x += xinc;
	  diff += dy;
	  if(diff>dx)
	    {
	      diff -= dx;
	      y += yinc;
	    }
	  put_pixel(bitmap,x,y,color);
	}
    }
  else
    {
      diff = dy/2;     
      for(i=0;i<dy;i++)
	{
	  y += yinc;
	  diff += dx;
	  if(diff>dy)
	    {
	      diff -= dy;
	      x += xinc;
	    }
	  put_pixel(bitmap,x,y,color);
	}
    }
}

D3 Vertex[7];   
D2 ProVertex[7];
D3 O;

main()
{
int i;
unsigned char *screen = (char *)0xa0000;
union REGS regs;       
__djgpp_nearptr_enable(); // desactive toutes les protections memoire
screen += __djgpp_conventional_base;
regs.x.ax=0x013;
int86(0x10, &regs, &regs);

O.x = 160;
O.y = 100;
O.z = 500;

Vertex[0].x = -100;  Vertex[0].y = -100;  Vertex[0].z = -100;
Vertex[1].x =  100;  Vertex[1].y = -100;  Vertex[1].z = -100;
Vertex[2].x =  100;  Vertex[2].y =  100;  Vertex[2].z = -100;
Vertex[3].x = -100;  Vertex[3].y =  100;  Vertex[3].z = -100;
Vertex[4].x =  100;  Vertex[4].y = -100;  Vertex[4].z =  100;
Vertex[5].x = -100;  Vertex[5].y = -100;  Vertex[5].z =  100;
Vertex[6].x = -100;  Vertex[6].y =  100;  Vertex[6].z =  100;
Vertex[7].x =  100;  Vertex[7].y =  100;  Vertex[7].z =  100;

for(i=0;i<8;i++)
{
ProVertex[i].x=(Vertex[i].x<<8)/(Vertex[i].z+O.z)+O.x;
ProVertex[i].y=(Vertex[i].y<<8)/(Vertex[i].z+O.z)+O.y;
}

while(!kbhit())
{
line(screen,ProVertex[0].x,ProVertex[0].y,ProVertex[1].x,ProVertex[1].y,15);
line(screen,ProVertex[1].x,ProVertex[1].y,ProVertex[2].x,ProVertex[2].y,15);
line(screen,ProVertex[2].x,ProVertex[2].y,ProVertex[3].x,ProVertex[3].y,15);
line(screen,ProVertex[3].x,ProVertex[3].y,ProVertex[0].x,ProVertex[0].y,15);
line(screen,ProVertex[4].x,ProVertex[4].y,ProVertex[5].x,ProVertex[5].y,15);
line(screen,ProVertex[5].x,ProVertex[5].y,ProVertex[6].x,ProVertex[6].y,15);
line(screen,ProVertex[6].x,ProVertex[6].y,ProVertex[7].x,ProVertex[7].y,15);
line(screen,ProVertex[7].x,ProVertex[7].y,ProVertex[4].x,ProVertex[4].y,15);
line(screen,ProVertex[0].x,ProVertex[0].y,ProVertex[5].x,ProVertex[5].y,15);
line(screen,ProVertex[1].x,ProVertex[1].y,ProVertex[4].x,ProVertex[4].y,15);
line(screen,ProVertex[2].x,ProVertex[2].y,ProVertex[7].x,ProVertex[7].y,15);
line(screen,ProVertex[3].x,ProVertex[3].y,ProVertex[6].x,ProVertex[6].y,15);  
}
  
__djgpp_nearptr_disable(); // reactive toutes les protections memoire
regs.x.ax=0x03;
int86(0x10, &regs, &regs);
return;
}



