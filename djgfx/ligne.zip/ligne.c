//////////////////////////////////////////////
//                                          //
//	      TRACER UNE LIGNE              //
//           copyright Logarno              //
//        logarno@planet-d.net.net          //
//       http://logarno.planet-d.net        //
//                                          //
//////////////////////////////////////////////

/*
On ecrit des pixels dans la direction de l'axe � plus forte denivelation en mettant � jour une variable qui est l'ecart entre le pente ideale et la pente trac�e et, lorsque cette variable depasse le seuil a partir duquel il est plus exacte d'ecrire un pixel suivant l'autre axe c'est a dire 1, dans la direction de l'axe � plus faible denivelation. 
*/

#include <dos.h>
#include <sys/nearptr.h>

void put_pixel(unsigned char *bitmap, int x, int y, unsigned char color)
{
bitmap[(y << 8) + (y << 6) + x] = color;
}

void ligne(unsigned char *bitmap, int x1,int y1, int x2,int y2, unsigned char color)
{
  int x,y,xinc,yinc,diff,i;
  int dx = abs(x2-x1);
  int dy = abs(y2-y1);

  if(x1<x2) xinc = 1;
  else	xinc = -1;

  if(y1<y2) yinc = 1;
  else	yinc = -1;

  x = x1;
  y = y1;

  if(dx>dy)
    {
      diff = dx/2;     
      for(i=0;i<dx;i++)
	{
	  x += xinc;
	  diff += dy;
	  if(diff>dx)
	    {
	      diff -= dx;
	      y += yinc;
	    }
	  put_pixel(bitmap,x,y,color);
	}
    }
  else
    {
      diff = dy/2;     
      for(i=0;i<dy;i++)
	{
	  y += yinc;
	  diff += dx;
	  if(diff>dy)
	    {
	      diff -= dy;
	      x += xinc;
	    }
	  put_pixel(bitmap,x,y,color);
	}
    }
}

main()
{
unsigned char *screen = (char *)0xa0000;
union REGS regs;
__djgpp_nearptr_enable(); // desactive toutes les protections memoires 
screen += __djgpp_conventional_base;
regs.x.ax=0x013;
int86(0x10, &regs, &regs);

while(!kbhit())
ligne(screen,1, 1, 320, 200, 15);
        
regs.x.ax=0x03;
int86(0x10, &regs, &regs);
__djgpp_nearptr_disable(); // reactive toutes les protections memoires   
return;
}



