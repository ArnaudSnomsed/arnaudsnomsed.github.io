//////////////////////////////////////////////
//                                          //
//         AFFICHAGE D'UN PIXEL		    //
//           copyright Logarno              //
//          logarno@planet-d.net            //
//       http://logarno.planet-d.net        //
//                                          //
//////////////////////////////////////////////

/*
On allume un pixel en envoyant l'indice de sa couleur aux coordonn�es souhait�es vers la memoire de l'ecran, represent� par un pointeur � l'adresse 0xa0000. En mode 13h elle represente 320*200 octets soit 64 Ko et est lineaire (bitmap). L'ordre d'affichage des pixel commence en haut a gauche, puis arriv� en bout de ligne on recommence � la ligne suivante, etc. Le calcul de la position en 2 dimensions est : 320 * y + x 
*/

#include <dos.h>
#include <sys/nearptr.h>

char *screen=(char *)0xa0000;

void put_pixel(int x,int y,char couleur)
{
screen[(y << 8) + (y << 6) + x] = couleur;
}

main()
{
union REGS regs;
__djgpp_nearptr_enable();
screen += __djgpp_conventional_base;
regs.x.ax = 0x013;
int86(0x10, &regs, &regs);

put_pixel(150, 100, 15);
getch();

regs.x.ax = 0x03;
int86(0x10, &regs, &regs);
__djgpp_nearptr_disable();
}

