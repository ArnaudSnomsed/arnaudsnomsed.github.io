/*
** bump.c for gba_bump
** http://logarno.planet-d.net/gba
** 
** made by Arnaud Desmons
** <logarno@planet-d.net>
** http://arnaud.desmons.free.fr
*/

#include "lambert.h"
#include "img.h"

#define u16 unsigned short
static long randBuffer = 0x5344;

static int getRandInt(int max)
{
  int temp = (int)(((randBuffer = randBuffer * 214013 + 2531011) >> 16) & 0x7FFF);
  return (temp * max) >> 15;
}

void wait4vsync()
{
  volatile unsigned short * vpos = ((volatile unsigned short *)(0x04000006));
  while( *vpos < 160 ) 
    /* busy loop */ ;
}

void plotRect( int x, int y, int w, int h, unsigned short int colour, u16 *scrn)
{
  int tmp;

  while (y < h)
    {
      tmp = x;
      while (tmp < w)
	scrn[(tmp++)+y*120] = (colour << 8) | colour;
      y++;
    }
}

void plotPixel( int x, int y, unsigned short colour, u16 *scrn)
{
  scrn[x + y * 120] = (colour << 8) | colour;
}

void bump(u16 *screen, int lx, int ly)
{
  int x,y,nx,ny;
  
  for (y = 0; y <= 160; y++)
    for (x = 0; x <= 120; x++)
      {
        nx = bmp[x+y*120+1] - bmp[x+y*120-1] - x + lx + 128;
        ny = bmp[x+y*120+1] - bmp[x+y*120-1] - y + ly + 128;
        if (nx > 255 || nx < 0)
          nx = 255;
        if (ny > 255 || ny < 0)
	  ny = 255;
	plotPixel(x, y, lambert[(nx) + (ny << 8)], screen);
      }
}

u16 *flip()
{
  if (*(u16 *)0x04000000 & 0x10)
    {  
      *((u16 *)0x04000000) &= ~0x10;
      return ((u16 *)0x600A000);
    }
  else
    {
      *((u16 *)0x04000000) |= 0x10;
      return ((u16 *)0x6000000);
    }
}

#define RGB(r,g,b) ((r)+((g)<<5)+((b)<<10))

int main()
{
  int x,y, xinc, yinc, loop;
  u16 *scrn;
  u16 *pal = (u16 *)0x05000000;
  *(u16 *)0x04000000 = 0x404;

  for(loop = 0; loop < 255; loop++)
    pal[loop] = RGB(0, loop * 32 / 255, 0);
  x = y = 0;
  xinc = 3;
  yinc = 5;
  while (1)
    {
      if (x < 0 || x > 120)
	xinc = - xinc;
      if (y < 0 || y > 160)
	yinc = - yinc;
      x += xinc;
      y += yinc;
      wait4vsync();
      scrn = (u16 *)flip();
      loop+=4;
      bump(scrn, x, y);
    }
}










