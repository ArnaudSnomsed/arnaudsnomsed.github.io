//////////////////////////////////////////////
//                                          //
//	GESTION D'UNE PALETTE DE COULEURS   //
//           copyright Logarno              //
//          logarno@planet-d.net            //
//       http://logarno.planet-d.net        //
//                                          //
//////////////////////////////////////////////

#include <sys/nearptr.h>
#include <dos.h>

void put_pixel(unsigned char *bitmap, int x, int y, unsigned char color)
{
bitmap[(y << 8) + (y << 6) + x] = color;
}

void set_palette(unsigned char color, unsigned char r, unsigned char g, unsigned char b)
{
  outp (0x03C8,color);
  outp (0x03C9,r);
  outp (0x03C9,g);
  outp (0x03C9,b);
}

main()
{
int i,x,y;
unsigned char *screen = (char *)0xA0000;
union REGS regs;
__djgpp_nearptr_enable(); // desactive toutes les protections memoire
screen += __djgpp_conventional_base;
regs.x.ax=0x013; //appelle le mode graphique
int86(0x10, &regs, &regs); //appelle le bios

for(i=0;i<64;i++)
{
set_palette(i,i,0,0);
set_palette(i+64,0,i,0);
set_palette(i+128,0,0,i);
set_palette(i+192,i,i,i);
}

while(!kbhit())
{
	for(x=0;x<256;x++)
	{
	for(y=10;y<40;y++)
  		put_pixel(screen,x,y,x);
	}
}

regs.x.ax=0x03; //appelle le mode texte
int86(0x10, &regs, &regs); //appelle le bios
__djgpp_nearptr_disable(); // reactive toutes les protections memoire    
return;
}



