//////////////////////////////////////////////
//                                          //
//           AFFICHER UN PIXEL              //
//        (c)2000 Arnaud DESMONS            //
//          logarno@planet-d.net            //
//       http://logarno.planet-d.net        //
//                                          //
//////////////////////////////////////////////

/*
La distance d'un point du cercle � son centre sera toujours �gale au rayon. Or en faisant varier x, qui est la distance en abscisse qui le separe du centre on peut trouver y, distance en ordonn&eacute;e, car d'apres pythagore racine du rayon=racine(x+y) donc y=racine(r^2-X^2). Quand on dessine un cercle avec des carres, tels des pixels, on remarque qu'il y a 8 axes de symetries il est donc suffisant de ne calculer qu'un 8eme du cercle c'est a dire pour x=0; x&lt;=y; x++
*/

#include <dos.h>
#include <sys/nearptr.h>
#include <math.h>

void put_pixel(unsigned char *bitmap, int x, int y, unsigned char color)
{
bitmap[(y << 8) + (y << 6) + x] = color;
}

void circle(unsigned char *bitmap, int Ox, int Oy, int r, int color)
{
int X=0;
int Y=r;
r=r*r;
while(X<=Y)
{
put_pixel(bitmap, Ox+X, Oy-Y, color);
put_pixel(bitmap, Ox-X, Oy-Y, color);
put_pixel(bitmap, Ox+X, Oy+Y, color);
put_pixel(bitmap, Ox-X, Oy+Y, color);
put_pixel(bitmap, Ox+Y, Oy-X, color);
put_pixel(bitmap, Ox-Y, Oy-X, color);
put_pixel(bitmap, Ox+Y, Oy+X, color);
put_pixel(bitmap, Ox-Y, Oy+X, color);
X++;
Y=(sqrt(r-((double)X*X))+0.5);
}
}

main()
{
unsigned char *screen=(char *)0xa0000;
union REGS regs;
__djgpp_nearptr_enable();
screen += __djgpp_conventional_base;
regs.x.ax = 0x013;
int86(0x10, &regs, &regs);

while(!kbhit())
circle(screen, 150, 100, 50, 15);

regs.x.ax = 0x03;
int86(0x10, &regs, &regs);
__djgpp_nearptr_disable();
}

