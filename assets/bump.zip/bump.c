//////////////////////////////////////////////
//                                          //
//            LE BUMP MAPPING               //
//           copyright Logarno              //
//          logarno@citeweb.net             //
//       http://logarno.citeweb.net         //
//                                          //
//////////////////////////////////////////////

/*
Creer un effet de relief sur une texture sous entends des differences d'altitudes sur celle-ci. On determine l'altitude de chaque pixel par son intensit�, plus elle est importante plus le point est haut. On calcule ensuite l'inclinaison d'un pixel par rapport a la source de lumiere par l'intermediaire de sa normale. Les normales sont des vecteurs unitaires dont on peut calculer la composante z si l'on a x et y d'apr�s norme^2=x^2+y^2+z^2 donc z=1-racine(x^2+y^2), ce calcule ne peut se faire en temps reel on stocke donc au prealable dans un tableau, appel� environnement map, la composante z qui correspond aux composantes x et y normalis�es entre 1 et -1. x et y sont respectivement le degr� d'inclinaison par rapport � la source lumineuse en abscisse et en ordonn�, on l'obtient en comparant l'altitude donc l'intensit� des pixels avoisinants et en soustrayant la distance qui separent le pixel de la source de lumiere; en effet si l'on cherche � ce qu'un pixel soit de forte intensit� il faut que les composantes x et y soient faibles pour que la composante z tende vers 1 or si un pixel est inclin� de x unit�(s) a droite il faudra que la source lumineuse soit � x unit�(s) � droite du pixel pour que la soustraction donne un resultat faible et que la composante z s'en trouve augment�. 
*/

#include <stdio.h>
#include <dos.h>
#include <sys/nearptr.h>
#include <math.h>

#define ambient 0
#define diffuse 250

#define speed 5
#define amplitude 80

void set_palette(unsigned char color, unsigned char r, unsigned char g, unsigned char b)
{
  outp (0x03C8,color);
  outp (0x03C9,r);
  outp (0x03C9,g);
  outp (0x03C9,b);
}

int loadbmp(char *filename, unsigned char *bitmap, unsigned char *datapal)
{
FILE *f;
int i,line;
unsigned char *ptr;

f = fopen(filename,"rb");
fseek(f,53, SEEK_SET);
for (i=0;i<256;i++)
  {
  getc(f);			//vide
  datapal[i*3]=getc(f)>>2;	//bleu
  datapal[i*3+1]=getc(f)>>2;	//vert
  datapal[i*3+2]=getc(f)>>2;	//rouge 
  }

fseek(f,1078,SEEK_SET);

for(line=199;line>=0;line--)
	{
        ptr=(char *)bitmap+line*320;
	fread(ptr,320,1,f);
	}

fclose(f);
return 1;
}


// calcule la pseudo-normale et le modele de lambert de chaque pixel
void lambert(unsigned char *bitmap)
{
float nX,nY,nZ;
int x,y;

for (y=0;y<256;y++)
for (x=0;x<256;x++)
   {
     nX=(x-128)/128.0;
     nY=(y-128)/128.0;
     nZ=1-sqrt(nX*nX+nY*nY);
     if (nZ<0) nZ=0;

     bitmap[x+(y<<8)] = ambient + diffuse * nZ;
   }
}

void bumpmapping(int lx, int ly, unsigned char *envmap, unsigned char *input, unsigned char *output)
{
int x,y,nx,ny,offset=0;

for (y=0;y<200;y++){
      for (x=0;x<320;x++)
      {
	 // attribue une valeur selon les normales de ses voisins
	 nx=input[offset+1]-input[offset-1];
	 ny=input[offset+1]-input[offset-1];

	 // Ajuste les pseudo-normales selon la source lumineuse
	 nx-=(x-lx);
	 ny-=(y-ly);

	 // On s'assure d'etre dans les limites
	 if (nx>255 || nx<0) nx=255;
	 if (ny>255 || ny<0) ny=255;

	 output[offset++]=envmap[nx+(ny<<8)];
      }
}
}

main()
{
int i,lx,ly;
float count;
unsigned char *buffer, *bumpmap, *pal, *lambert_map, *screen = (char *)(0xa0000);
union REGS regs;
__djgpp_nearptr_enable(); // desactive toutes les protections memoire
screen += __djgpp_conventional_base;
regs.x.ax=0x013; // inscrit le mode choisit: 13h, dans le registre ax
int86(0x10, &regs, &regs); // appelle le mode par l'interruption no 10 avec en parametre le registre ax
bumpmap = (char *)malloc(64000);
buffer = (char *)malloc(64000);
pal = (char *)malloc(768);
lambert_map = (char *)malloc(65536);

   lambert(lambert_map);
   loadbmp("img.bmp",bumpmap,pal);
   for (i=0; i<192;i++)	set_palette(i,(i*63/192),(i*63/192),(i*63/192));
   for (i=192;i<256;i++) set_palette(i,63,63,63);
count=0;
while(!kbhit())
{
   count++;
   lx = cos(count/speed)*amplitude+288;
   ly = sin(count/speed)*amplitude+228;
   bumpmapping(lx,ly,lambert_map,bumpmap,buffer);
   while(!(inp(0x3da) & 8)); // attends que le canon � e- remonte
   memcpy(screen,buffer,64000);
}

regs.x.ax=0x03; // appelle le mode texte
int86(0x10, &regs, &regs);
__djgpp_nearptr_disable(); // reactive toutes les protections memoire
return;
}



