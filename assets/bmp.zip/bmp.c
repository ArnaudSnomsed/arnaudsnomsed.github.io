//////////////////////////////////////////////
//                                          //
//         AFFICHAGE D'UNE IMAGE BMP        //
//           copyright Logarno              //
//          logarno@planet-d.net            //
//       http://logarno.planet-d.net        //
//                                          //
//////////////////////////////////////////////

/*
En-t�te : 
Signification du champs			taille en octets
Signature = BM 				2
Taille fichier 				4
Inconnu					4
Offset de l'image dans le fichier	4
					v2.0	v4.0
Hauteur de l'image 			2	4
Largeur de l'image 			2	4
Nombre de plan (= 1) 			2	2
Bits par pixel 				2	2
Compression 				Nulle	4
Taille de l'image 			Nulle	4
R�solution horizontale 			Nulle	4
R�solution verticale 			Nulle	4
Nombre de couleurs 			Nulle	4
nombre de couleurs importantes		Nulle	4

Palette : 
Contient les intensites de chaques couleurs primaires sur 6 bits dans l'ordre alpha, bleu, vert, rouge. On ignore ici la composante alpha. 

Image ou bitmap : 
Les lignes y sont rang�es de bas en haut. 
*/

#include <stdio.h>
#include <conio.h>
#include <sys/nearptr.h>
#include <dos.h>

int loadbmp(char *filename, unsigned char *bitmap, unsigned char *datapal)
{
FILE *f;
int i,line;
unsigned char *ptr;

f = fopen(filename,"rb");
fseek(f,53, SEEK_SET);
for (i=0;i<256;i++)
  {
  getc(f);			//vide
  datapal[i*3]=getc(f)>>2;	//bleu
  datapal[i*3+1]=getc(f)>>2;	//vert
  datapal[i*3+2]=getc(f)>>2;	//rouge 
  }

fseek(f,1078,SEEK_SET);

for(line=199;line>=0;line--)
	{
        ptr=(char *)bitmap+line*320;
	fread(ptr,320,1,f);
	}

fclose(f);
return 1;
}

set_palette(unsigned char color, int red, int green, int blue)
{
outp(0x03C8, color); // alpha
outp(0x03C9, red);   // intensit� rouge
outp(0x03C9, green); // verte
outp(0x03C9, blue);  // bleue
}

main()
{
unsigned char *buffer, *pal, *screen = (char *)0xa0000;
int i;
union REGS regs; 
__djgpp_nearptr_enable(); // desactive toutes les protections memoire
screen += __djgpp_conventional_base; 
regs.x.ax=0x013;
int86(0x10, &regs, &regs);
buffer = (char *)malloc(64000);
pal = (char *)malloc(768);

loadbmp("img.bmp",buffer,pal);
for(i=0;i<256;i++)
set_palette(i, pal[i*3+2], pal[i*3+1], pal[i*3+0]);
memcpy(screen,buffer,64000);
getch();

regs.x.ax=0x03;
int86(0x10, &regs, &regs);
__djgpp_nearptr_disable(); // reactive toutes les protections memoire
return;
}