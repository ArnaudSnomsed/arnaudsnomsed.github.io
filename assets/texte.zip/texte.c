//////////////////////////////////////////////
//                                          //
//        TEXTE EN MODE GRAPHIQUE           //
//           copyright Logarno              //
//          logarno@planet-d.net            //
//       http://logarno.planet-d.net        //
//                                          //
//////////////////////////////////////////////

/*
Il existe une police de caractere stock�e en ROM � l'adresse 0xffa6e, c'est un tableau qui contient une serie de caractere de 8*8 bits. On obtient donc un caractere en multipliant sa valeur ASCII par 8; on ajoute alors cette valeur au pointeur initialis� � 0xffa6e. On transferer ensuite, vers l'ecran, la portion 8*8 qui debute la ou est notre pointeur. 
*/

#include <sys/nearptr.h>
#include <dos.h>

#define CHAR_WIDTH  8
#define CHAR_HEIGHT 8

unsigned char *rom_char_set = (char *)0xffa6e;

void blit_string(int x, int y, int color, char *string, unsigned char *buffer)
{
int index;
int offset, x2, y2;

char *work_char;
unsigned char bit_mask = 0x80;

	for(index=0; string[index] != 0; index++) 
	{
		work_char = rom_char_set + string[index] * CHAR_HEIGHT;
		offset = (y << 8) + (y << 6) + x+(index<<3);

		for(y2=0; y2<CHAR_HEIGHT; y2++) 
		{
			bit_mask = 0x80;
			for(x2=0; x2<CHAR_WIDTH; x2++)
                        {
                                if((*work_char & bit_mask))
                                	buffer[offset+x2] = color;
                                bit_mask = (bit_mask >> 1);
                        }
			offset += 320;
			work_char++;
             }
	}
}

main()
{
unsigned char *screen = (char *)0xa0000;

union REGS regs;
screen += __djgpp_conventional_base;
rom_char_set += __djgpp_conventional_base;
__djgpp_nearptr_enable();    
regs.x.ax = 0x013;
int86(0x10, &regs, &regs);
        
blit_string(50, 60, 15, "Hello World", screen);
getch(); 
	  
regs.x.ax = 0x03;
int86(0x10, &regs, &regs);
__djgpp_nearptr_disable();  // reactive toute les protections memoire
}
