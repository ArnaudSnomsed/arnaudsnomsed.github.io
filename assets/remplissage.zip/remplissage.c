//////////////////////////////////////////////
//                                          //
//              LA ROTATION                 //
//         copyright Arnaud DESMONS         //
//          logarno@planet-d.net            //
//       http://logarno.planet-d.net        //
//                                          //
//////////////////////////////////////////////

#include <stdlib.h>
#include <math.h>  //sin(); cos();
#include <sys/nearptr.h>
#include <dos.h>

char *video_buffer = (char *)0xa0000;
char *double_buffer;

/* coordon�es de l'origine du repere */
int Ox = 160;
int Oy = 100;
int Oz = 500;

struct debutfin
{
  int debut,fin;
};

/* structure 3d */
struct D3
{
  int x,y,z;
};

/* structure 2d */
struct D2
{
  int x,y;
};

struct D3 Vertex[8];     /* les sommets du cube (3d) */
struct D3 RotVertex[8];  /* les sommets apres rotation (3d) */
struct D2 ProVertex[8];  /* les sommets apres projection (2d) */
struct debutfin scanboard[200];

void Initialiser(void)
{
  Vertex[0].x = -100;  Vertex[0].y = -100;  Vertex[0].z = -100;
  Vertex[1].x =  100;  Vertex[1].y = -100;  Vertex[1].z = -100;
  Vertex[2].x =  100;  Vertex[2].y =  100;  Vertex[2].z = -100;
  Vertex[3].x = -100;  Vertex[3].y =  100;  Vertex[3].z = -100;
  Vertex[4].x =  100;  Vertex[4].y = -100;  Vertex[4].z =  100;
  Vertex[5].x = -100;  Vertex[5].y = -100;  Vertex[5].z =  100;
  Vertex[6].x = -100;  Vertex[6].y =  100;  Vertex[6].z =  100;
  Vertex[7].x =  100;  Vertex[7].y =  100;  Vertex[7].z =  100;
}


void Rotation(int alpha, int beta,int gamma) /* respectivement les angles de rotation autour de l'axe x, y et z */
{
  int i;
  float matrix[3][3];      /* Matrice de rotation 3*3 */
  float Sin[360],Cos[360]; /* Tableaux precalcul�s de sinus et cosinus */

for(i=0;i<360;i++)
  {
    Sin[i]=sin(i*3.14/180);
    Cos[i]=cos(i*3.14/180);
  }
 
// Calcul de la matrice de rotation 3*3

  matrix[0][0] = Cos[gamma]*Cos[beta];
  matrix[1][0] = -Sin[gamma]*Cos[beta];
  matrix[2][0] = -Sin[beta];

  matrix[0][1] = Cos[gamma]*Sin[beta]*Sin[alpha]+Sin[gamma]*Cos[alpha];
  matrix[1][1] = Sin[gamma]*Sin[beta]*-Sin[alpha]+Cos[alpha]*Cos[gamma];
  matrix[2][1] = Sin[alpha]*Cos[beta];

  matrix[0][2] = Cos[gamma]*Sin[beta]*Cos[alpha]-Sin[gamma]*Sin[alpha];
  matrix[1][2] = -Sin[gamma]*Sin[beta]*Cos[alpha]-Cos[gamma]*Sin[alpha];
  matrix[2][2] = Cos[alpha]*Cos[beta];

  for(i=0;i<8;i++)
  {
    RotVertex[i].x =   matrix[0][0]*Vertex[i].x
		     + matrix[1][0]*Vertex[i].y
		     + matrix[2][0]*Vertex[i].z;

    RotVertex[i].y =   matrix[0][1]*Vertex[i].x
		     + matrix[1][1]*Vertex[i].y
		     + matrix[2][1]*Vertex[i].z;

    RotVertex[i].z =   matrix[0][2]*Vertex[i].x
		     + matrix[1][2]*Vertex[i].y
		     + matrix[2][2]*Vertex[i].z;
  }
}

void Projection(void)
{
  int i;

  for(i=0;i<8;i++)
  {
    ProVertex[i].x=(RotVertex[i].x<<8)/(RotVertex[i].z+Oz)+Ox;
    ProVertex[i].y=(RotVertex[i].y<<8)/(RotVertex[i].z+Oz)+Oy;
  }
}

void PutPixel(int x, int y, int couleur)
{
  double_buffer[y*320+x]=couleur;
}

void scanline(int x1,int y1, int x2,int y2)
{
  int temp,y;
  long x,m;

  if(y2!=y1)
  {
    if(y2<y1)
    {
      temp=y1;
      y1=y2;
      y2=temp;

      temp=x1;
      x1=x2;
      x2=temp;
    }
    x=(long)x1<<8;

    m=((long)(x2-x1)<<8) / ((long)(y2-y1));

    x+=m;
    y1++;

    for(y=y1;y<=y2;y++)
    {
      if((y>=0) & (y<640))
	if(scanboard[y].debut==-16000)
	  scanboard[y].debut=x>>8;
	else
	  scanboard[y].fin=x>>8;
      x+=m;
    }
  }
}

void Remplir(int x1, int y1, int x2, int y2, int x3, int y3, int couleur)
{
int x, y;

for(y=0;y<200;y++) scanboard[y].debut=scanboard[y].fin=-16000;

scanline(x1,y1,x2,y2);
scanline(x2,y2,x3,y3);
scanline(x3,y3,x1,y1);

for(y=0;y<200;y++)
{
if(scanboard[y].debut>scanboard[y].fin)
    {
      x=scanboard[y].debut;
      scanboard[y].debut=scanboard[y].fin;
      scanboard[y].fin=x;
    }
if (scanboard[y].debut!= -16000)
    {
      if(scanboard[y].fin==-16000)
	scanboard[y].fin=scanboard[y].debut;

for(x=scanboard[y].debut;x<scanboard[y].fin;x++)
PutPixel(x,y,couleur);
}
}
}

main()
{
char car;
int alpha,beta,gamma;
union REGS regs;              
__djgpp_nearptr_enable(); // desactive toutes les protections memoire
video_buffer += __djgpp_conventional_base;
       
regs.x.ax=0x013;
int86(0x10, &regs, &regs);

Initialiser();

 while(!kbhit())
  {
        Projection();
	Remplir(ProVertex[0].x,ProVertex[0].y,ProVertex[1].x,ProVertex[1].y,ProVertex[3].x,ProVertex[3].y,15);
	while(!(inp(0x03DA)& 8)); //attends que le canon remonte
	double_buffer = (char *)malloc(64000);
	memcpy((char *)video_buffer,(char *)double_buffer, 64000);
	free(double_buffer);
	memset(double_buffer, 0, 64000);
        Rotation(alpha,beta,gamma);

        alpha=(alpha+2)%360;
        beta=(beta+3)%360;
        gamma=(gamma+2)%360;
  }

regs.x.ax=0x03;
int86(0x10, &regs, &regs);
__djgpp_nearptr_disable(); // reactive toutes les protections memoire
 
return;
}



