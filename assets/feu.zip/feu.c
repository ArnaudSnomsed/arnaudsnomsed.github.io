/******************************
* EFFET DE FEU                *
* (c)2000 Arnaud DESMONS      *
* logarno@planet-d.net        *
* http://logarno.planet-d.net *
******************************/

#include <stdio.h>
#include <dos.h>
#include <sys/nearptr.h>

void set_palette(unsigned char index, unsigned char r, unsigned char g, unsigned char b)
{
  outp (0x03C8,index);  // indice de la couleur
  outp (0x03C9,r);      // composante rouge
  outp (0x03C9,g);      // verte
  outp (0x03C9,b);      // bleue
}

void fire(unsigned char *bitmap){
int offset,x,y;
unsigned char color;
   /* chaque pixel de la derniere ligne recoit aleatoirement la couleur 255 ou 0 */
   for(x=0; x<320; x++) bitmap[64000+x]=rand()%2?255:0;
   /* chaque pixel recoit la moyenne de ses voisins du bas et est attenue(refroidie) de 1 */
   for(offset=0;offset<64000;offset++)
   {
        /* moyenne */
        color=(bitmap[offset+321] + bitmap[offset+319]
        + bitmap[offset+320] + bitmap[offset+640])>>2;
        /* attenuation */
        if(color>5) color-=4;
        else color=0;
        /* attribution */
        bitmap[offset]=color;
   }
}


main()
{
unsigned char *screen = (char *)(0xa0000);
unsigned char *buffer = (char *)malloc(64000);
int i;
union REGS regs;
__djgpp_nearptr_enable(); // desactive toutes les protections memoire
screen += __djgpp_conventional_base;
regs.x.ax=0x013; //appelle le mode graphique
int86(0x10, &regs, &regs); //appelle le bios
for(i=0; i<64; i++)
{
set_palette(i+192,255,255,255);    // blanc
set_palette(i+128,255,255,i);  // blanc->jaune
set_palette(i+64,255,i,0);     // jaune->rouge
set_palette(i,i,0,0);          // rouge->noir
}
memset(buffer,0,64000);
while(!kbhit())   //tant qu'aucune touche n'est pressee
{
fire(buffer);
while(!(inp(0x3da)&8)); // attends que le canon � e- remonte
memcpy(screen,buffer,64000);
}
regs.x.ax=0x03; //appelle le mode texte
int86(0x10, &regs, &regs); //appelle le bios
__djgpp_nearptr_disable(); // reactive toutes les protections memoire
return;
}
