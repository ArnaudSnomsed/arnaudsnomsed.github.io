/******************************
* TEXTURE MAPPING             *
* (c)2001 Arnaud DESMONS      *
* logarno@planet-d.net        *
* http://logarno.planet-d.net *
******************************/

#include <stdlib.h>
#include <math.h>  //sin(); cos();
#include <sys/nearptr.h>
#include <dos.h>
#include <stdio.h>
#include <conio.h>

#define ambient 0
#define diffuse 250

#define speed 5
#define amplitude 0

/* coordon�es de l'origine du repere */
int Ox = 160;
int Oy = 100;
int Oz = 500;

struct debutfin
{
  int debut,fin,u1,v1,u2,v2;
};

/* structure 3d */
struct D3
{
  int x,y,z;
};

/* structure 2d */
struct D2
{
  int x,y;
};

struct D3 Vertex[8];     /* les sommets du cube (3d) */
struct D3 RotVertex[8];  /* les sommets apres rotation (3d) */
struct D2 ProVertex[8];  /* les sommets apres projection (2d) */
struct debutfin scanboard[200];

void Initialiser(void)
{
  Vertex[0].x = -100;  Vertex[0].y = -100;  Vertex[0].z = -100;
  Vertex[1].x =  100;  Vertex[1].y = -100;  Vertex[1].z = -100;
  Vertex[2].x =  100;  Vertex[2].y =  100;  Vertex[2].z = -100;
  Vertex[3].x = -100;  Vertex[3].y =  100;  Vertex[3].z = -100;
  Vertex[4].x =  100;  Vertex[4].y = -100;  Vertex[4].z =  100;
  Vertex[5].x = -100;  Vertex[5].y = -100;  Vertex[5].z =  100;
  Vertex[6].x = -100;  Vertex[6].y =  100;  Vertex[6].z =  100;
  Vertex[7].x =  100;  Vertex[7].y =  100;  Vertex[7].z =  100;
}


void Rotation(int alpha, int beta,int gamma) /* respectivement les angles de rotation autour de l'axe x, y et z */
{
  int i;
  float matrix[3][3];      /* Matrice de rotation 3*3 */
  float Sin[360],Cos[360]; /* Tableaux precalcul�s de sinus et cosinus */

for(i=0;i<360;i++)
  {
    Sin[i]=sin(i*3.14/180);
    Cos[i]=cos(i*3.14/180);
  }
 
// Calcul de la matrice de rotation 3*3

  matrix[0][0] = Cos[gamma]*Cos[beta];
  matrix[1][0] = -Sin[gamma]*Cos[beta];
  matrix[2][0] = -Sin[beta];

  matrix[0][1] = Cos[gamma]*Sin[beta]*Sin[alpha]+Sin[gamma]*Cos[alpha];
  matrix[1][1] = Sin[gamma]*Sin[beta]*-Sin[alpha]+Cos[alpha]*Cos[gamma];
  matrix[2][1] = Sin[alpha]*Cos[beta];

  matrix[0][2] = Cos[gamma]*Sin[beta]*Cos[alpha]-Sin[gamma]*Sin[alpha];
  matrix[1][2] = -Sin[gamma]*Sin[beta]*Cos[alpha]-Cos[gamma]*Sin[alpha];
  matrix[2][2] = Cos[alpha]*Cos[beta];
  for(i=0;i<8;i++)
  {
    RotVertex[i].x =   matrix[0][0]*Vertex[i].x
		     + matrix[1][0]*Vertex[i].y
		     + matrix[2][0]*Vertex[i].z;

    RotVertex[i].y =   matrix[0][1]*Vertex[i].x
		     + matrix[1][1]*Vertex[i].y
		     + matrix[2][1]*Vertex[i].z;

    RotVertex[i].z =   matrix[0][2]*Vertex[i].x
		     + matrix[1][2]*Vertex[i].y
		     + matrix[2][2]*Vertex[i].z;
  }
}

void Projection(void)
{
  int i;

  for(i=0;i<8;i++)
  {
    ProVertex[i].x=(RotVertex[i].x<<8)/(RotVertex[i].z+Oz)+Ox;
    ProVertex[i].y=(RotVertex[i].y<<8)/(RotVertex[i].z+Oz)+Oy;
  }
}

void scanline(int x1,int y1,int u1, int v1, int x2,int y2,int u2, int v2)
{
  int temp,y;
  long x,m,u,v,uinc,vinc;

  if(y2!=y1)
  {
    if(y2<y1)
    {
      temp=y1;
      y1=y2;
      y2=temp;

      temp=x1;
      x1=x2;
      x2=temp;

      temp=u1;
      u1=u2;
      u2=temp;

      temp=v1;
      v1=v2;
      v2=temp;
    }
    x=(long)x1<<8;
    u=(long)u1<<8;
    v=(long)v1<<8;

    m=((long)(x2-x1)<<8) / ((long)(y2-y1));
    uinc=((long)(u2-u1)<<8) / ((long)(y2-y1));
    vinc=((long)(v2-v1)<<8) / ((long)(y2-y1));

    x+=m;
    y1++;
    u+=uinc;
    v+=vinc;
  
    for(y=y1;y<=y2;y++)
    {
     	if(scanboard[y].debut==-16000){
	  scanboard[y].debut=x>>8;
          scanboard[y].u1=u>>8;
          scanboard[y].v1=v>>8;
          }
	else{
	  scanboard[y].fin=x>>8;
          scanboard[y].u2=u>>8;
          scanboard[y].v2=v>>8;
          }
      x+=m;
      u+=uinc;
      v+=vinc;
  }
}
}
set_palette(unsigned char color, int red, int green, int blue)
{
outp(0x03C8, color); // index
outp(0x03C9, red);   // intensit� rouge
outp(0x03C9, green); // verte
outp(0x03C9, blue);  // bleue
}

void load_pcx(char *filename, unsigned char *buffer, unsigned char *datapal){
FILE *f;
unsigned char data,count;
int i,color,offset=0;
f=fopen(filename,"rb");
fseek(f,-768,SEEK_END);
fread(datapal,768,1,f);
fseek(f,128,SEEK_SET);
while(offset<64000){
   fread(&data,1,1,f);
   if((data&0xc0)==0xc0)
      {
      count=(data&0x3f);
      fread(&data,1,1,f);
      while(count>0)
	 {
         buffer[offset++]=data;
         count--;
         }
       }
   else buffer[offset++]=data;
   }
fclose(f);
}

void h_line_tex(int x1,int u1,int v1,int x2,int u2,int v2,int y, char *texture, unsigned char *screen)
{
  long longueur;
  long deltax,deltay;
  long xincr,yincr;
  long xpos,ypos;
  int  indice;
  long src;
  int  x,temp;


  if(x1>x2)
  {
    temp=x1; x1=x2; x2=temp;
    temp=u1; u1=u2; u2=temp;
    temp=v1; v1=v2; v2=temp;
  }

  longueur=x2-x1+1;
  if(longueur>0)
  {
    deltax = u2-u1+1;
    deltay = v2-v1+1;

    indice = y*320+x1;

    src    = v1*320+u1;    /* 320 = largeur texture */

    xincr=((long)(deltax)<<8)/(long)longueur;
    yincr=((long)(deltay)<<8)/(long)longueur;

    xpos=u1<<8;
    ypos=v1<<8;

    for(x=x1;x<=x2;x++)
    {
      src = (xpos>>8) + (ypos & 0xFF00) + ((ypos & 0xFF00)>>2);
      screen[indice++]=texture[src];
      xpos+=xincr;
      ypos+=yincr;
    }
  }
}

void fill_poly_tex(int x1, int y1, int u1, int v1, int x2, int y2, int u2, int v2, int x3, int y3, int u3, int v3, unsigned char *texture, unsigned char *output)
{
int x, y;

for(y=0;y<200;y++) scanboard[y].debut=scanboard[y].fin=-16000;

scanline(x1,y1,u1,v1,x2,y2,u2,v2);
scanline(x2,y2,u2,v2,x3,y3,u3,v3);
scanline(x3,y3,u3,v3,x1,y1,u1,v1);

for(y=0;y<200;y++)
{

if (scanboard[y].debut!= -16000)
    {
      if(scanboard[y].fin==-16000)
	scanboard[y].fin=scanboard[y].debut;

h_line_tex(scanboard[y].debut,scanboard[y].u1,scanboard[y].v1,
		  scanboard[y].fin, scanboard[y].u2,scanboard[y].v2,
		  y,texture,output);
}
}
}
void lambert(unsigned char *bitmap)
{
float nX,nY,nZ;
int x,y;

for (y=0;y<256;y++)
for (x=0;x<256;x++)
   {
     nX=(x-128)/128.0;
     nY=(y-128)/128.0;
     nZ=1-sqrt(nX*nX+nY*nY);
     if (nZ<0) nZ=0;

     bitmap[x+(y<<8)] = ambient + diffuse * nZ;
   }
}

void bumpmapping(int lx, int ly, unsigned char *envmap, unsigned char *input, unsigned char *output)
{
int x,y,nx,ny,offset=0;

for (y=0;y<200;y++){
      for (x=0;x<320;x++)
      {
	 // attribue une valeur selon les normales de ses voisins
	 nx=input[offset+1]-input[offset-1];
	 ny=input[offset+1]-input[offset-1];

	 // Ajuste les pseudo-normales selon la source lumineuse
	 nx-=(x-lx);
	 ny-=(y-ly);

	 // On s'assure d'etre dans les limites
	 if (nx>255 || nx<0) nx=255;
	 if (ny>255 || ny<0) ny=255;

	 output[offset++]=envmap[nx+(ny<<8)];
      }
}
}

main()
{
char car;
int i,lx,ly;
float count;
int alpha,beta,gamma;
unsigned char *buffer, *bumpmap, *double_buffer, *pal, *lambert_map, *screen = (char *)(0xa0000);
int color;
union REGS regs; 
__djgpp_nearptr_enable(); // desactive toutes les protections memoire
screen += __djgpp_conventional_base;
regs.x.ax=0x013;
int86(0x10, &regs, &regs);
bumpmap = (char *)malloc(64000);
buffer = (char *)malloc(64000);
pal = (char *)malloc(768);
lambert_map = (char *)malloc(65536);

   lambert(lambert_map);
   load_pcx("img.pcx",bumpmap,pal);
   for (i=0; i<192;i++)	set_palette(i,(i*63/192),(i*63/192),(i*63/192));
   for (i=192;i<256;i++) set_palette(i,63,63,63);
Initialiser();
count=0;
 while(!kbhit())
  {
        Projection();
   count++;
   lx = cos(count/speed)*amplitude+288;
   ly = sin(count/speed)*amplitude+228;
   bumpmapping(lx,ly,lambert_map,bumpmap,buffer);
fill_poly_tex(ProVertex[0].x,ProVertex[0].y,0,0,ProVertex[1].x,ProVertex[1].y,320,0,ProVertex[3].x,ProVertex[3].y,0,200,buffer, double_buffer);
fill_poly_tex(ProVertex[2].x,ProVertex[2].y,320,200,ProVertex[1].x,ProVertex[1].y,320,0,ProVertex[3].x,ProVertex[3].y,0,200,buffer, double_buffer);
	while(!(inp(0x03DA)& 8)); //attends que le canon remonte
	double_buffer = (char *)malloc(64000);
	memcpy((char *)screen,(char *)double_buffer, 64000);

	free(double_buffer);
	memset(double_buffer, 255, 64000);
        Rotation(alpha,beta,gamma);

        alpha=(alpha+2)%360;
        beta=(beta+3)%360;
        gamma=(gamma+2)%360;
  }

regs.x.ax=0x03;
int86(0x10, &regs, &regs);
__djgpp_nearptr_disable(); // reactive toutes les protections memoire
 for(i=0;i<200;i++)
//printf("scanboard[i].debut:%d;scanboard[i].fin:%d;scanboard[i].u1:%d;scanboard[i].v1:%d;scanboard[i].u2:%d;scanboard[i].v2:%d\n",scanboard[i].debut,scanboard[i].fin,scanboard[i].u1,scanboard[i].v1,scanboard[i].u2,scanboard[i].v2);
return;
}



