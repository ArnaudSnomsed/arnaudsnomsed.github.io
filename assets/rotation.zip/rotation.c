//////////////////////////////////////////////
//                                          //
//              LA ROTATION                 //
//           copyright Logarno              //
//          logarno@planet-d.net            //
//       http://logarno.planet-d.net        //
//                                          //
//////////////////////////////////////////////

#include <math.h>
#include <sys/nearptr.h>
#include <dos.h>

char *video_buffer = (char *)0xa0000;
char *double_buffer;

typedef struct D3
{
  int x,y,z;
};

typedef struct D2
{
  int x,y;
};

D3 Vertex[8];   /* les sommets du cube          */
D3 RotVertex[8];  /* les sommets apres rotation   */
D2 ProVertex[8];  /* les sommets apres projection */
D3 O;

void Initialiser(void)
{
  O.x = 160;
  O.y = 100;
  O.z = 500;
  
  Vertex[0].x = -100;  Vertex[0].y = -100;  Vertex[0].z = -100;
  Vertex[1].x =  100;  Vertex[1].y = -100;  Vertex[1].z = -100;
  Vertex[2].x =  100;  Vertex[2].y =  100;  Vertex[2].z = -100;
  Vertex[3].x = -100;  Vertex[3].y =  100;  Vertex[3].z = -100;
  Vertex[4].x =  100;  Vertex[4].y = -100;  Vertex[4].z =  100;
  Vertex[5].x = -100;  Vertex[5].y = -100;  Vertex[5].z =  100;
  Vertex[6].x = -100;  Vertex[6].y =  100;  Vertex[6].z =  100;
  Vertex[7].x =  100;  Vertex[7].y =  100;  Vertex[7].z =  100;
}

void Rotation(int Xa, int Ya, int Za)
{
  int i;
  float matrix[3][3];       /* Matrice de rotation 3*3 */
  float Sin[360],Cos[360];   /* Tableaux precalcules de sinus et cosinus */

for(i=0;i<360;i++)
  {
    Sin[i]=sin(i * 3.14 / 180);
    Cos[i]=cos(i * 3.14 / 180);
  }
 
  // Calcul de la matrice de rotation 3*3

  matrix[0][0] = Cos[Za]*Cos[Ya];
  matrix[1][0] = Sin[Za]*Cos[Ya];
  matrix[2][0] = -Sin[Ya];

  matrix[0][1] = Cos[Za]*Sin[Ya]*Sin[Xa] - Sin[Za]*Cos[Xa];
  matrix[1][1] = Sin[Za]*Sin[Ya]*Sin[Xa] + Cos[Xa]*Cos[Za];
  matrix[2][1] = Sin[Xa]*Cos[Ya];

  matrix[0][2] = Cos[Za]*Sin[Ya]*Cos[Xa] + Sin[Za]*Sin[Xa];
  matrix[1][2] = Sin[Za]*Sin[Ya]*Cos[Xa] - Cos[Za]*Sin[Xa];
  matrix[2][2] = Cos[Xa]*Cos[Ya];

  for(i=0;i<8;i++)
  {
    RotVertex[i].x =   matrix[0][0]*Vertex[i].x
		   + matrix[1][0]*Vertex[i].y
		   + matrix[2][0]*Vertex[i].z;

    RotVertex[i].y =   matrix[0][1]*Vertex[i].x
		   + matrix[1][1]*Vertex[i].y
		   + matrix[2][1]*Vertex[i].z;

    RotVertex[i].z =   matrix[0][2]*Vertex[i].x
		   + matrix[1][2]*Vertex[i].y
		   + matrix[2][2]*Vertex[i].z;
  }
}

void Projection(void)
{
  int i;

  for(i=0;i<8;i++)
  {
    ProVertex[i].x=(RotVertex[i].x<<8)/(RotVertex[i].z+O.z)+O.x;
    ProVertex[i].y=(RotVertex[i].y<<8)/(RotVertex[i].z+Oz)+O.y;
  }
}

void PutPixel(int x, int y, int couleur)
{
  double_buffer[y*320+x]=couleur;
}

void ligne(int x1,int y1, int x2,int y2, int couleur)
{
  int x,y,xinc,yinc,diff,i;
  int dx = abs(x2-x1);
  int dy = abs(y2-y1);

  if(x1<x2) xinc = 1;
  else	xinc = -1;

  if(y1<y2) yinc = 1;
  else	yinc = -1;

  x = x1;
  y = y1;

  if(dx>dy)
    {
      diff = dx/2;     
      for(i=0;i<dx;i++)
	{
	  x += xinc;
	  diff += dy;
	  if(diff>dx)
	    {
	      diff -= dx;
	      y += yinc;
	    }
	  PutPixel(x,y,couleur);
	}

    }
  else
    {
      diff = dy/2;     
      for(i=0;i<dy;i++)
	{
	  y += yinc;
	  diff += dx;
	  if(diff>dy)
	    {
	      diff -= dy;
	      x += xinc;
	    }
	  PutPixel(x,y,couleur);
	}
    }
}

void Afficher(int couleur) 
{
line(ProVertex[0].x,ProVertex[0].y,ProVertex[1].x,ProVertex[1].y,couleur);
line(ProVertex[1].x,ProVertex[1].y,ProVertex[2].x,ProVertex[2].y,couleur);
line(ProVertex[2].x,ProVertex[2].y,ProVertex[3].x,ProVertex[3].y,couleur);
line(ProVertex[3].x,ProVertex[3].y,ProVertex[0].x,ProVertex[0].y,couleur);
line(ProVertex[4].x,ProVertex[4].y,ProVertex[5].x,ProVertex[5].y,couleur);
line(ProVertex[5].x,ProVertex[5].y,ProVertex[6].x,ProVertex[6].y,couleur);
line(ProVertex[6].x,ProVertex[6].y,ProVertex[7].x,ProVertex[7].y,couleur);
line(ProVertex[7].x,ProVertex[7].y,ProVertex[4].x,ProVertex[4].y,couleur);
line(ProVertex[0].x,ProVertex[0].y,ProVertex[5].x,ProVertex[5].y,couleur);
line(ProVertex[1].x,ProVertex[1].y,ProVertex[4].x,ProVertex[4].y,couleur);
line(ProVertex[2].x,ProVertex[2].y,ProVertex[7].x,ProVertex[7].y,couleur);
line(ProVertex[3].x,ProVertex[3].y,ProVertex[6].x,ProVertex[6].y,couleur);
}

main()
{
int xa, ya, za;
union REGS regs;              
__djgpp_nearptr_enable(); // desactive toutes les protections memoire
video_buffer += __djgpp_conventional_base;
       
regs.x.ax=0x013;
int86(0x10, &regs, &regs);

Initialiser();

while(!kbhit()) // attend qu'une touche soit press�e
  {
	Projection();
	Afficher(15);
	//attends que le canon ... e- remonte
	while(!(inp(0x03DA)& 8));
	double_buffer = (char *)malloc(64000);
	memcpy((char *)video_buffer,(char *)double_buffer, 64000);
	free(double_buffer);
	memset(double_buffer, 0, 64000);
	Rotation(xa, ya, za);
	xa=(xa+1)%360;
	ya=(ya+3)%360;
	za=(za+1)%360;
  }

regs.x.ax=0x03;
int86(0x10, &regs, &regs);
__djgpp_nearptr_disable(); // reactive toutes les protections memoire
 
return;
}



